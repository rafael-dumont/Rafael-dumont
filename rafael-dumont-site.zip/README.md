# Rafael Dumont — Portfólio One Page

Inspirado no site motion.zajno.com

## Tecnologias
- HTML
- CSS
- JavaScript (GSAP + ScrollTrigger)